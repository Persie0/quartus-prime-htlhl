/mnt/BigData/intelFPGA_lite/20.1/modelsim_ase/linuxaloem/vsim -do tb_SimpleStateMachine.do
